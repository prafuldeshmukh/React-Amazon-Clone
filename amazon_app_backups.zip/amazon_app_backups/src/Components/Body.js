import React from "react";
import Imageslider from "./Imageslider";
import Prodcutcard from "./Prodcutcard";

const Body = () => {
  return (
    <>
      <Imageslider />
      <Prodcutcard />
    </>
  );
};

export default Body;
