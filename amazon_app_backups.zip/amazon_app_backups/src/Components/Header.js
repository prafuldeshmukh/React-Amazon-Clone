import React from "react";
import Mainmenu from "./Mainmenu";

const Header = () => {
  return (
    <div>
      <header className="header">
        <div className="container container-header">
          <div className="logo-container border-white">
            <div className="logo" />
            <span className="dotin">.in</span>
          </div>
          <div className="address-container border-white">
            <p className="hello">Hello</p>
            <div className="icon-address">
              <i className="fa-solid fa-location-dot icon-location" />
              <p>Select your address</p>
            </div>
          </div>
          <div className="search-container">
            <select className="search-select">
              <option>All</option>
            </select>
            <input type="text" className="search-input" />
            <div className="search-icon">
              <i className="fa-solid fa-magnifying-glass" />
            </div>
          </div>
          <div className="language-container border-white">
            <p>English</p>
            <div className="lauguge-image">
              <img src="https://media.istockphoto.com/vectors/vector-flag-of-the-republic-of-india-proportion-23-the-national-flag-vector-id1051236720?k=20&m=1051236720&s=612x612&w=0&h=ATObRTHmTosADa9zaB2dQPn_VAQmG1XYH2x92kzc304=" />
            </div>
          </div>
          <div className="login-container border-white">
            <p>
              Hello,<span>sign in</span>
            </p>
            <p className="account">Account &amp; Lists</p>
          </div>
          <div className="return-order-container">
            <p>Returns</p>
            <div className="order">&amp; Orders</div>
            <p />
          </div>
          <div className="cart-container border-white">
            <i className="fa-solid fa-cart-shopping" />
            Cart
          </div>
        </div>
      </header>
      <mainmenu></mainmenu>
    </div>
  );
};

export default Header;
