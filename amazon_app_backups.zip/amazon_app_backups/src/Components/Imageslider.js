import React from "react";

const Imageslider = () => {
  return (
    <section>
      <div className="image-container">
        <div className="image-list">
          <div className="image-item">
            <img src="https://m.media-amazon.com/images/I/71cp9PVuTfL._SX3000_.jpg" />
          </div>
          <div className="image-item">
            <img src="https://m.media-amazon.com/images/I/61GnAucagBL._SX3000_.png" />
          </div>
          <div className="image-item">
            <img src="https://m.media-amazon.com/images/I/71qlKqpJnlL._SX3000_.jpg" />
          </div>
          <div className="image-item">
            <img src="https://m.media-amazon.com/images/I/71cQMXCLSvL._SX3000_.jpg" />
          </div>
          <div className="image-item">
            <img src="https://m.media-amazon.com/images/I/61aURrton0L._SX3000_.jpg" />
          </div>
          <div className="image-item">
            <img src="https://m.media-amazon.com/images/I/61O72XhcEkL._SX3000_.jpg" />
          </div>
          <div className="image-item">
            <img src="https://m.media-amazon.com/images/I/61VuJdpjvaL._SX3000_.jpg" />
          </div>
          <div className="image-item">
            <img src="https://m.media-amazon.com/images/I/61UrRx+3LLL._SX3000_.jpg" />
          </div>
        </div>
        <div className="image-btn-container">
          <button className="slider-btn" id="slide-btn-left">
            <i className="fa-solid fa-chevron-left" />
          </button>
          <button className="slider-btn" id="slide-btn-right" />
        </div>
      </div>
    </section>
  );
};

export default Imageslider;
