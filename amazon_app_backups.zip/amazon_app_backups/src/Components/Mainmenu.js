import React from "react";
//navigation
const Mainmenu = () => {
  return (
    <>
      <nav className="nav">
        <div className="container container-nav">
          <ul>
            <li className="border-white" id="open-nav-sidebar">
              <span className="open-nav-slider">
                <i className="fa-solid fa-bars" />
                All
              </span>
            </li>
            <li className="border-white">
              <a href="#">Best Sellers</a>
            </li>
            <li className="border-white">
              <a href="#">Today's Deals</a>
            </li>
            <li className="border-white">
              <a href="#">Mobiles</a>
            </li>
            <li className="border-white">
              <a href="#">Customer Service</a>
            </li>
            <li className="border-white">
              <a href="#">Electronic</a>
            </li>
            <li className="border-white">
              <a href="#">Home &amp; Kitchen</a>
            </li>
            <li className="border-white">
              <a href="#">Fashion</a>
            </li>
            <li className="border-white">
              <a href="#">Book</a>
            </li>
            <li className="border-white prime-image-hover">
              <a href="#">Prime</a>
              <div className="prime-image">
                <img src="https://m.media-amazon.com/images/G/31/prime/NavFlyout/TryPrime/2018/Apr/IN-Prime-PIN-TryPrime-MultiBen-Apr18-400x400._CB442254244_.jpg" />
              </div>
            </li>
          </ul>
          <div className="nav-right-image-amazon-prime">
            <img src="https://m.media-amazon.com/images/G/31/img17/Home/AmazonTV/Ravina/Desktop/Watch-Entertainment-for-FREE_400-x39._CB605460886_.jpg" />
          </div>
        </div>
      </nav>
    </>
  );
};

export default Mainmenu;
