import React from "react";
// <!--today's deals -->

const Productdeals = () => {
  return (
    <>
      section class="today_deals_container"&gt;
      <div className="today_deals_heading">
        <h1>Today's Deals</h1>
        <p>
          <a href="#">See all deals</a>
        </p>
      </div>
      <div className="today_deals_product_container">
        <div className="today_deals_btn_container">
          <button className="today_deal_btn" id="today_deal_btn_prev">
            <i className="fa-solid fa-angle-left" />
          </button>
          <button className="today_deal_btn" id="today_deal_btn_next">
            <i className="fa-solid fa-angle-right" />
          </button>
        </div>
        <div className="today_deals_product_list">
          <div className="today_deals_product_item">
            <img src="https://m.media-amazon.com/images/I/411mbYGYIdL._AC_SY200_.jpg" />
            <div className="discount_Contaienr">
              <a href="#">Up to 52% off</a>
              <a href="#">Deal of the day</a>
            </div>
            <p>adidas and Campus Footwear</p>
          </div>
          <div className="today_deals_product_item">
            <img src="https://m.media-amazon.com/images/I/411mbYGYIdL._AC_SY200_.jpg" />
            <div className="discount_Contaienr">
              <a href="#">Up to 52% off</a>
              <a href="#">Deal of the day</a>
            </div>
            <p>adidas and Campus Footwear</p>
          </div>
          <div className="today_deals_product_item">
            <img src="https://m.media-amazon.com/images/I/411mbYGYIdL._AC_SY200_.jpg" />
            <div className="discount_Contaienr">
              <a href="#">Up to 52% off</a>
              <a href="#">Deal of the day</a>
            </div>
            <p>adidas and Campus Footwear</p>
          </div>
          <div className="today_deals_product_item">
            <img src="https://m.media-amazon.com/images/I/411mbYGYIdL._AC_SY200_.jpg" />
            <div className="discount_Contaienr">
              <a href="#">Up to 52% off</a>
              <a href="#">Deal of the day</a>
            </div>
            <p>adidas and Campus Footwear</p>
          </div>
          <div className="today_deals_product_item">
            <img src="https://m.media-amazon.com/images/I/411mbYGYIdL._AC_SY200_.jpg" />
            <div className="discount_Contaienr">
              <a href="#">Up to 52% off</a>
              <a href="#">Deal of the day</a>
            </div>
            <p>adidas and Campus Footwear</p>
          </div>
        </div>
      </div>
    </>
  );
};

export default Productdeals;
