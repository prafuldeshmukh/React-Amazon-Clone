import React from "react";

const SidebarMenu = () => {
  //<!--sidebar navigation-->
  return (
    <>
      <div
        class="sidebar-container-navigation"
        id="sidebar-container-navigation-id"
      >
        <div class="sidebar-left-part">
          <div class="sidebar-top">
            <i class="fa-solid fa-circle-user"></i>
            <h2>
              Hello, <span>sign in</span>
            </h2>
          </div>
          <div class="sidebar-wrap">
            <div class="sidebar-item">
              <h2>Trending</h2>
              <p>Best Sellers</p>
              <p>New Releases</p>
              <p>Movers and Shakers</p>
            </div>
            <div class="sidebar-item">
              <h2>Digital Content And Devices</h2>
              <p>Echo & Alexa</p>
              <p>Fire TV</p>
              <p>Kindle E-Readers & eBooks</p>
              <p>Audible Audiobooks</p>
              <p>Amazon Prime Video</p>
              <p>Amazon Prime Music</p>
            </div>
            <div class="sidebar-item">
              <h2>Shop By Category</h2>
              <p>Mobiles, Computes</p>
              <p>TV, Appliances, Electronic</p>
              <p>Men's Fashion</p>
              <p>Women's Fashion</p>
              <p>See All</p>
            </div>
            <div class="sidebar-item">
              <h2>Programs & Features</h2>
              <p>Gift Cards & Mobile Recharges</p>
              <p>Flight Tickets</p>
              <p>#Foundlt-OnAmazon</p>
              <p>Clearance store</p>
            </div>
            <div class="sidebar-item">
              <h2>Help & Settings</h2>
              <p>Your Account</p>
              <p>Customer Service</p>
              <p>Sign in</p>
            </div>
          </div>
        </div>
        <button id="sidebar-navigation-close">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>
    </>
  );
};

export default SidebarMenu;
