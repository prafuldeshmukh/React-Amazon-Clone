import React from "react";

const Useraction = () => {
  return <div>Useraction</div>;
};

export default Useraction;
