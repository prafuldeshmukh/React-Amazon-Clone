import React from "react";

const navfooterback = () => {
  return <div>navfooterback</div>;
};

export default navfooterback;
